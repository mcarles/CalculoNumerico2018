function f=edof_ex2final1718(t,y)

f=[y(2);y(2)-1];
