function f=edof1(t,y)

f=[y(1)+y(2);  2*y(1)*y(2)];
%f=[z(2);-z(1)];

